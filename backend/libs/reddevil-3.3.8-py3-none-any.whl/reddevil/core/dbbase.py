# copyright Chessdevil Consulting BVBA 2015 - 2022

import logging
import uuid
from pydantic import BaseModel
from datetime import datetime, date, timezone
from typing import List, Dict, Any, Optional, Type, cast, Union, TypeVar
from bson.objectid import ObjectId
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError

from reddevil.core import RdNotFound, RdBadRequest, RdInternalServerError
from reddevil.core.mongodb import get_mongodb

logger = logging.getLogger(__name__)
EncodedModel = TypeVar("EncodedModel", bound=BaseModel)


def encode_model(e: dict, validator_class: Type[EncodedModel]) -> EncodedModel:
    """
    validates and encodes a result dict as a validator class
    """
    try:
        eo = validator_class(**e)
    except Exception:
        logger.exception(f"cannot encode model {validator_class.__name__}")
        raise RdInternalServerError(
            description=f"CannotEncode{validator_class.__name__}"
        )
    return eo


class DbBase:
    """
    Base class for Mongo collection async operations
    All operations are dumb, unaware of any business logic
    RdExceptions can be raised
    """

    COLLECTION: Optional[str] = None  # should be overriden
    VERSION = 1
    SIMPLEFIELDS: list = []
    HIDDENFIELDS: list = []
    IDGENERATOR = "uuid"
    HISTORY = False

    @classmethod
    def idgenerator(cls):
        if cls.IDGENERATOR == "uuid":
            return str(uuid.uuid4())
        if cls.IDGENERATOR == "objectid":
            return ObjectId()

    @classmethod
    def id_to_native(cls, id):
        if cls.IDGENERATOR == "uuid":
            return str(id)
        if cls.IDGENERATOR == "objectid":
            return ObjectId(id)

    @classmethod
    def id_from_native(cls, _id):
        if cls.IDGENERATOR == "uuid":
            return str(_id)
        if cls.IDGENERATOR == "objectid":
            return str(_id)

    @classmethod
    async def add(cls, docin: Dict[str, Any] | Type[EncodedModel]) -> str:
        """
        add a new record, starting form dict_in, return the id
        """
        db = get_mongodb()
        doc = docin.copy() if isinstance(docin, dict) else docin.model_dump()
        coll = db[cls.COLLECTION]
        if "id" in doc:
            doc["_id"] = cls.id_to_native(doc.pop("id"))
        else:
            doc["_id"] = cls.idgenerator()
        doc["_version"] = cls.VERSION
        doc["_creationtime"] = datetime.now(timezone.utc)
        doc["_modificationtime"] = datetime.now(timezone.utc)
        username = doc.pop("_username", "_unknown")
        try:
            await coll.insert_one(doc)
            if cls.HISTORY:
                collhist = db[f"{cls.COLLECTION}__history"]
                collhist.insert_one(
                    {
                        "operation": "insert",
                        "ts": datetime.now(timezone.utc),
                        "user": username,
                        "values": doc,
                    }
                )
        except:
            logger.exception(f"error inserting {cls.COLLECTION} record")
            raise RdBadRequest(description=f"CannotCreate{cls.COLLECTION}")
        return doc["_id"]

    @classmethod
    async def find_multiple(cls, options: dict = {}) -> List[dict] | List[EncodedModel]:
        """
        find multiple records
        """
        db = get_mongodb()
        coll = db[cls.COLLECTION]
        docs = []
        filter = options.copy()
        if "id" in filter:
            filter["_id"] = cls.id_to_native(filter.pop("id"))
        model = filter.pop("_model", None)
        _fieldlist = filter.pop("_fieldlist", cls.SIMPLEFIELDS)
        _sort = filter.pop("_sort", None)
        _limit = filter.pop("_limit", 0)
        projfields = (
            {k: 1 for k in _fieldlist}
            if _fieldlist
            else {k: 0 for k in cls.HIDDENFIELDS} or None
        )
        async for doc in coll.find(
            filter, projection=projfields, sort=_sort, limit=_limit
        ):
            doc["id"] = cls.id_from_native(doc.pop("_id"))
            docs.append(doc)
        return [encode_model(d, model) for d in docs] if model else docs

    @classmethod
    async def find_single(cls, options: dict) -> Dict[str, Any] | EncodedModel:
        """
        find a single doc,
        raises NotFound if nothing is found
        """
        db = get_mongodb()
        coll = db[cls.COLLECTION]
        filter = options.copy()
        if "id" in filter:
            filter["_id"] = cls.id_to_native(filter.pop("id"))
        model = filter.pop("_model", None)
        fieldlist = filter.pop("_fieldlist", None)
        projfields = (
            {k: 1 for k in fieldlist}
            if fieldlist
            else {k: 0 for k in cls.HIDDENFIELDS} or None
        )
        doc = await coll.find_one(filter, projection=projfields)
        if not doc:
            raise RdNotFound(description=f"CannotFindSingle{cls.COLLECTION}")
        doc["id"] = cls.id_from_native(doc.pop("_id"))
        return encode_model(doc, model) if model else doc

    @classmethod
    async def update(
        cls,
        docfilter: Union[str, dict],
        docupdate: Dict[str, Any] | Type[EncodedModel],
        options: dict = {},
    ) -> Dict[str, Any] | Type[EncodedModel]:
        """
        updates a single doc
        docfilter is the filter to find the single doc
        docupdate are the fields to be updated (without changing other fields)
        raises NotFound if event is not found
        """
        db = get_mongodb()
        coll = db[cls.COLLECTION]
        if isinstance(docfilter, str):
            docfilter = {"_id": cls.id_to_native(docfilter)}
        dictupdate = (
            docupdate.copy() if isinstance(docupdate, dict) else doc.model_dump()
        )
        if "_modificationtime" not in dictupdate:
            dictupdate["_modificationtime"] = datetime.now(timezone.utc)
        fullupdate = options.copy()
        model = fullupdate.pop("_model", None)
        username = fullupdate.pop("_username", "_unknown")
        extraupdates = fullupdate.pop("$set", None)
        if extraupdates:
            dictupdate.update(extraupdates)
        fullupdate["$set"] = dictupdate
        if cls.HISTORY:
            # get the old values
            cursor = coll.find(docfilter, {k: 1 for k in dictupdate.keys()})
            olddocs = [d for d in await cursor.to_list(None)]
        doc = await coll.find_one_and_update(
            docfilter,
            fullupdate,
            projection={k: 0 for k in cls.HIDDENFIELDS},
            return_document=ReturnDocument.AFTER,
        )
        if cls.HISTORY:
            collhist = db[f"{cls.COLLECTION}__history"]
            collhist.insert_one(
                {
                    "operation": "update",
                    "ts": datetime.now(timezone.utc),
                    "user": username,
                    "filter": docfilter,
                    "values": fullupdate,
                    "oldvalues": olddocs,
                }
            )
        if not doc:
            raise RdNotFound(description=f"CannotFind_{cls.COLLECTION}")
        doc["id"] = cls.id_from_native(doc.pop("_id"))
        return encode_model(doc, model) if model else doc

    @classmethod
    async def delete(cls, id: str, options: dict = {}) -> None:
        """
        delete a single doc
        """
        db = get_mongodb()
        coll = db[cls.COLLECTION]
        rs = await coll.delete_one({"_id": cls.id_to_native(id)})
        if cls.HISTORY:
            username = options.get("_username", "_unknown")
            collhist = db[f"{cls.COLLECTION}__history"]
            collhist.insert_one(
                {
                    "operation": "delete",
                    "ts": datetime.now(timezone.utc),
                    "user": username,
                    "filter": {"_id": cls.id_to_native(id)},
                }
            )
        if rs.deleted_count != 1:
            raise RdNotFound(description=f"CannotFind{cls.COLLECTION}")
