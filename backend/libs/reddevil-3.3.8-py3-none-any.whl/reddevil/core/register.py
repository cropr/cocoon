# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2021

import logging
import importlib

logger = logging.getLogger("reddevil")


class Settings:
    """
    simplified version of django settings handling
    creates attributes on self for all uppercase attributes in settings module
    """

    def __init__(self, settings_module):
        mod = importlib.import_module(settings_module)
        for setting in dir(mod):
            if setting.isupper():
                setting_value = getattr(mod, setting)
                setattr(self, setting, setting_value)


def _reddevilapp(app, settingsmodule, baseurl):
    """
    singleton function that should not be called directly
    """
    if not hasattr(_reddevilapp, "rdattr"):
        setattr(
            _reddevilapp,
            "rdattr",
            {
                "app": app,
                "settingsmodule": settingsmodule,
                "baseurl": baseurl,
                "wrappedsettings": None,
            },
        )


def register_app(app=None, settingsmodule=None, baseurl=None):
    if hasattr(_reddevilapp, "rdattr"):
        logger.info("register_app was already called, skipping ...")
        return
    _reddevilapp(app, settingsmodule, baseurl)


def get_app():
    if not hasattr(_reddevilapp, "rdattr"):
        logger.info("get_app: register_app was not yer called, skipping")
        return None
    return getattr(_reddevilapp, "rdattr")["app"]


def get_baseurl():
    if not hasattr(_reddevilapp, "rdattr"):
        logger.info("get_app: register_app was not yer called, skipping")
        return None
    return getattr(_reddevilapp, "rdattr")["baseurl"]


def get_settings():
    if not hasattr(_reddevilapp, "rdattr"):
        logger.info("get_app: register_app was not yer called, skipping")
        return None
    rdattr = getattr(_reddevilapp, "rdattr")
    wrappedsettings = rdattr["wrappedsettings"]
    if wrappedsettings is None:
        wrappedsettings = Settings(rdattr["settingsmodule"])
        rdattr["wrappedsettings"] = wrappedsettings
    return wrappedsettings
