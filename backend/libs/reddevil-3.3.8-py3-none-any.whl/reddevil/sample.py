# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

# all database request come in here, but we do not use dataclasess
# if needed we define extra models an do marshalling functions at the service level
# All _id are translatesd to stringified id on output
# All functions expect stringified id as input

from reddevil.core.model import DocumentType, InsertType, ListType, UpdateType
from reddevil.core.dbbase import DbBase
from typing import Dict, Any, List, Optional
from pydantic import Field


class Sample(DocumentType):
    name: Optional[str]
    size: Optional[int]
    id: Optional[str]


class _Sample:
    name: str
    size: int
    _id: str


class SampleInsert(InsertType):
    name: str
    size: int


class SampleUpdate(UpdateType):
    name: Optional[str]
    size: Optional[int]


class SampleList(ListType):
    samples: list[Sample]


class DbSample(DbBase):
    COLLECTION = "sample"
    DOCUMENTTYPE = "sample"
    VERSION = 1
    DT = Sample
    IT = SampleInsert
    UT = SampleUpdate
    LT = SampleList
    ItemField = "samples"
