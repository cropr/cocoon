# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2021

import logging
from typing import Type, Optional, TypeVar
from reddevil.core import RdInternalServerError
from pydantic import BaseModel

